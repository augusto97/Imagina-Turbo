<?php
/**
 * Activación, desactivación, actualización de esquema y desinstalación.
 *
 * Objetivo: activar/desactivar no deja residuos que afecten al sitio, y desinstalar no deja nada.
 *
 * @package ImaginaTurbo
 */

declare(strict_types=1);

namespace ImaginaTurbo\Core;

use ImaginaTurbo\Core\Config\CompiledConfig;
use ImaginaTurbo\Core\Config\ConfigCompiler;
use ImaginaTurbo\Core\Config\Settings;
use ImaginaTurbo\Core\Events\EventLog;
use ImaginaTurbo\Core\Safety\KillSwitch;
use ImaginaTurbo\Core\Safety\SafeMode;
use ImaginaTurbo\Modules\AssetManager\AssetRules;
use ImaginaTurbo\Modules\Firewall\HtaccessWriter;
use ImaginaTurbo\Modules\Firewall\OriginLock;
use ImaginaTurbo\Modules\PluginFilter\RuleStore;
use ImaginaTurbo\Modules\Rum\RumInsights;
use ImaginaTurbo\Support\Filesystem;
use ImaginaTurbo\Support\Jobs;

/**
 * Ciclo de vida del plugin.
 */
final class Installer {

	public const DB_VERSION        = 10;
	public const DB_VERSION_OPTION = 'itb_db_version';
	public const CAPABILITY        = 'itb_manage';

	/** Opciones propias (todas se borran al desinstalar). */
	public const OPTIONS = [ Settings::OPTION, self::DB_VERSION_OPTION, 'itb_cf_token', 'itb_cf_state', 'itb_site_key', 'itb_profiler_rollup', 'itb_hub', 'itb_audit_last', 'itb_warm_state', 'itb_purge_state', 'itb_cf_analytics', 'itb_cf_drift', 'itb_cf_firewall', 'itb_cf_challenge', OriginLock::STATE_OPTION, RuleStore::OPTION, RumInsights::OPTION, AssetRules::OPTION, 'itb_db_audit', 'itb_db_schedule_state', 'itb_fleet', 'itb_fleet_snapshots', 'itb_hub_nonces', 'itb_diag_queries', 'itb_frag_verify', 'itb_zaraz_state', 'itb_zaraz_scan', 'itb_budgets_state', 'itb_image_audit', 'itb_verifier', 'itb_verifier_key', 'itb_turnstile_secret', 'itb_connector_changes' ];

	/** Tablas propias sin prefijo. */
	public const TABLES = [ 'itb_events', 'itb_route_samples', 'itb_metrics_hourly', 'itb_purge_queue', 'itb_cf_snapshots', 'itb_rum_hist', 'itb_rum_events', 'itb_db_backups', 'itb_connector_tokens' ];

	public function __construct(
		private readonly Settings $settings,
		private readonly ConfigCompiler $compiler,
		private readonly MuLoaderInstaller $muLoader,
		private readonly EventLog $events,
		private readonly Jobs $jobs,
		private readonly string $dataDir,
	) {
	}

	/**
	 * Activación en el sitio actual.
	 */
	public function activate(): void {
		Filesystem::ensureDataDir( $this->dataDir );
		self::createTables();
		$this->settings->ensureInitialized();
		self::addCapability();

		$loader = $this->muLoader->install();
		$result = $this->compiler->compile();
		$this->jobs->schedule();

		$this->events->info(
			'core',
			'activate',
			__( 'Plugin activado.', 'imagina-turbo' ),
			[
				'loader' => $loader,
				'config' => $result['ok'],
				'errors' => $result['errors'],
			]
		);
	}

	/**
	 * Desactivación: quita todo lo que actúa sobre el sitio (loader, config compilada, banderas,
	 * tareas programadas). Conserva ajustes, tablas y el archivo de kill switch puesto a mano.
	 */
	public function deactivate(): void {
		$this->events->info( 'core', 'deactivate', __( 'Plugin desactivado.', 'imagina-turbo' ) );
		$this->jobs->unschedule();
		$this->muLoader->uninstall();
		$this->compiler->delete();

		// Las reglas del firewall en .htaccess son del plugin: sin él no deben quedarse.
		if ( ! function_exists( 'get_home_path' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( HtaccessWriter::stripFile( get_home_path() . '.htaccess' ) ) {
			$this->events->info( 'firewall', 'htaccess_removed', __( 'Reglas del firewall quitadas del .htaccess al desactivar el plugin. En OpenLiteSpeed, reinicia el servidor para que se apliquen.', 'imagina-turbo' ) );
		}

		// Los accesos de Claude no sobreviven a la desactivación (0.22.1).
		( new \ImaginaTurbo\Modules\Connector\TokenStore() )->revokeAll();

		foreach ( [ SafeMode::FLAG, SafeMode::COUNTER, ...SafeMode::LEGACY ] as $name ) {
			$file = $this->dataDir . '/' . $name;
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}
		self::removeDataDirIfUnused( $this->dataDir );
	}

	/**
	 * 0.21.2: los archivos internos pasaron a .php con guarda (hasta la 0.21.1 eran .json y .log, que
	 * OpenLiteSpeed y nginx servían por URL). La bandera del modo seguro se conserva; el resto son
	 * contadores y registros de paso que se borran. Barato si no queda nada: corre en cada request de
	 * admin, porque la actualización no avisa.
	 */
	public static function migrateDataFiles( string $dataDir, SafeMode $safeMode ): void {
		if ( '' === $dataDir || ! is_dir( $dataDir ) ) {
			return;
		}
		$safeMode->migrateLegacy();
		$file = $dataDir . '/rum-limits.json';
		if ( is_file( $file ) ) {
			wp_delete_file( $file );
		}
		foreach ( glob( $dataDir . '/experiments/*.log' ) ?: [] as $file ) {
			wp_delete_file( $file );
		}
	}

	/**
	 * Crea o actualiza tablas si cambió la versión del esquema.
	 */
	public static function maybeUpgrade(): void {
		$previous = (int) get_option( self::DB_VERSION_OPTION, 0 );
		if ( self::DB_VERSION !== $previous ) {
			// Desde la versión 6 de la base, via_cf distingue tráfico directo de local: las muestras
			// anteriores no sirven para saber si el origen está cerrado.
			if ( $previous < 6 ) {
				update_option( OriginLock::STATE_OPTION, [ 'since' => time() ], false );
			}
			self::createTables();
			// Hasta la 0.3 LSCache podía guardar en caché privada las respuestas del admin: se descartan.
			do_action( 'litespeed_purge_private_all' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- hook público de LSCache.
			// Y podía guardar el carrito de la Store API de un visitante (fase 3): se descartan las
			// respuestas REST guardadas (LSCache las etiqueta con "REST").
			do_action( 'litespeed_purge', 'REST' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- hook público de LSCache.
		}
	}

	/**
	 * Crea las tablas con dbDelta.
	 */
	public static function createTables(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$table   = $wpdb->prefix . 'itb_events';

		dbDelta(
			"CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  module varchar(40) NOT NULL,
  type varchar(40) NOT NULL,
  severity tinyint(4) NOT NULL DEFAULT 0,
  message varchar(255) NOT NULL,
  context longtext NULL,
  PRIMARY KEY  (id),
  KEY created_at (created_at),
  KEY module_type (module,type)
) {$charset};"
		);

		$samples = $wpdb->prefix . 'itb_route_samples';
		dbDelta(
			"CREATE TABLE {$samples} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  request_type varchar(20) NOT NULL,
  route_key varchar(150) NOT NULL,
  path_hash char(16) NOT NULL,
  status smallint(5) unsigned NOT NULL DEFAULT 200,
  ms mediumint(8) unsigned NOT NULL DEFAULT 0,
  mem_kb int(10) unsigned NOT NULL DEFAULT 0,
  queries smallint(5) unsigned NOT NULL DEFAULT 0,
  cacheable tinyint(1) NOT NULL DEFAULT 0,
  via_cf tinyint(1) NOT NULL DEFAULT 0,
  source tinyint(3) unsigned NOT NULL DEFAULT 0,
  anon tinyint(1) NOT NULL DEFAULT 0,
  overhead_us int(10) unsigned NOT NULL DEFAULT 0,
  set_cookies varchar(255) NULL,
  cache_control varchar(100) NULL,
  phases text NULL,
  plugins_cost text NULL,
  PRIMARY KEY  (id),
  KEY created_at (created_at),
  KEY route (request_type,route_key)
) {$charset};"
		);

		$hourly = $wpdb->prefix . 'itb_metrics_hourly';
		dbDelta(
			"CREATE TABLE {$hourly} (
  hour datetime NOT NULL,
  request_type varchar(20) NOT NULL,
  route_key varchar(150) NOT NULL,
  n int(10) unsigned NOT NULL DEFAULT 0,
  ms_p50 mediumint(8) unsigned NOT NULL DEFAULT 0,
  ms_p95 mediumint(8) unsigned NOT NULL DEFAULT 0,
  mem_p50 int(10) unsigned NOT NULL DEFAULT 0,
  mem_p95 int(10) unsigned NOT NULL DEFAULT 0,
  queries_avg smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (hour,request_type,route_key)
) {$charset};"
		);

		// Cola de purga y recalentado: un elemento por (tipo, valor), sin repetidos.
		$queue = $wpdb->prefix . 'itb_purge_queue';
		dbDelta(
			"CREATE TABLE {$queue} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  kind char(1) NOT NULL,
  item_hash char(32) NOT NULL,
  item text NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY item_hash (item_hash),
  KEY kind (kind,id)
) {$charset};"
		);

		// Snapshots de Cloudflare: estado de la zona antes de cada cambio (fase 2b).
		$snapshots = $wpdb->prefix . 'itb_cf_snapshots';
		dbDelta(
			"CREATE TABLE {$snapshots} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  zone_id varchar(64) NOT NULL,
  reason varchar(100) NOT NULL,
  payload longtext NOT NULL,
  PRIMARY KEY  (id),
  KEY zone (zone_id,id)
) {$charset};"
		);

		// RUM (fase 6, esquema v7): solo contadores. Histogramas por métrica para calcular el p75 sin guardar
		// cada medición, y eventos (LCP, transiciones, bfcache) con un mapa de 64 bits de IP-hash para
		// estimar cuántos visitantes distintos los enviaron. Nunca se guarda una IP. Claves dentro de 767 bytes
		// con utf8mb4 (MySQL 5.6 / COMPACT): plantilla de 40 y valor de 120 caracteres.
		$hist = $wpdb->prefix . 'itb_rum_hist';
		dbDelta(
			"CREATE TABLE {$hist} (
  hour datetime NOT NULL,
  template varchar(40) NOT NULL,
  device char(1) NOT NULL,
  metric varchar(8) NOT NULL,
  bucket smallint(5) unsigned NOT NULL,
  n int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (hour,template,device,metric,bucket)
) {$charset};"
		);
		$events = $wpdb->prefix . 'itb_rum_events';
		dbDelta(
			"CREATE TABLE {$events} (
  day date NOT NULL,
  kind varchar(8) NOT NULL,
  template varchar(40) NOT NULL,
  device char(1) NOT NULL,
  value varchar(120) NOT NULL,
  n int(10) unsigned NOT NULL DEFAULT 0,
  ip_bits bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (day,kind,template,device,value)
) {$charset};"
		);

		// Respaldos de las acciones de base de datos (fase 7, esquema v8): cada fila borrada o cambiada,
		// en JSON, para poder restaurar el lote. "op" dice cómo: insert (volver a insertar la fila) o
		// update (volver a poner los valores guardados en la fila con esa clave).
		$backups = $wpdb->prefix . 'itb_db_backups';
		dbDelta(
			"CREATE TABLE {$backups} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  batch char(12) NOT NULL,
  created_at datetime NOT NULL,
  action varchar(40) NOT NULL,
  tbl varchar(64) NOT NULL,
  op varchar(10) NOT NULL,
  row_data longtext NOT NULL,
  restored_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY batch (batch)
) {$charset};"
		);

		// Conector de Claude (0.22.0): un acceso por fila. Los tokens solo se guardan como hash.
		$tokens = $wpdb->prefix . 'itb_connector_tokens';
		dbDelta(
			"CREATE TABLE {$tokens} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  client_id varchar(255) NOT NULL,
  client_name varchar(100) NOT NULL,
  scope varchar(60) NOT NULL,
  resource varchar(255) NOT NULL,
  access_hash char(64) NOT NULL,
  access_expires int(10) unsigned NOT NULL,
  refresh_hash char(64) NOT NULL,
  prev_refresh_hash char(64) NOT NULL DEFAULT '',
  refresh_expires int(10) unsigned NOT NULL,
  created_at int(10) unsigned NOT NULL,
  last_used_at int(10) unsigned NOT NULL DEFAULT 0,
  last_ip varchar(45) NOT NULL DEFAULT '',
  revoked tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY access_hash (access_hash),
  KEY refresh_hash (refresh_hash),
  KEY prev_refresh_hash (prev_refresh_hash)
) {$charset};"
		);

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, true );
	}

	public static function addCapability(): void {
		$role = get_role( 'administrator' );
		if ( null !== $role && ! $role->has_cap( self::CAPABILITY ) ) {
			$role->add_cap( self::CAPABILITY );
		}
	}

	/**
	 * Desinstalación completa (llamada desde uninstall.php). En multisite recorre todos los sitios.
	 */
	public static function uninstall( string $pluginDir ): void {
		if ( is_multisite() ) {
			$siteIds = get_sites(
				[
					'fields' => 'ids',
					'number' => 0,
				]
			);
			foreach ( $siteIds as $siteId ) {
				switch_to_blog( (int) $siteId );
				self::uninstallSite();
				restore_current_blog();
			}
		} else {
			self::uninstallSite();
		}

		( new MuLoaderInstaller( $pluginDir, WPMU_PLUGIN_DIR ) )->uninstall();

		$dataDir = EarlyLoader::dataDir();
		if ( is_dir( $dataDir ) && defined( 'WP_CONTENT_DIR' ) ) {
			Filesystem::removeDir( $dataDir, WP_CONTENT_DIR );
		}
	}

	/**
	 * Borra datos del sitio actual: tablas, opciones, capacidad, tareas.
	 */
	private static function uninstallSite(): void {
		global $wpdb;
		foreach ( self::TABLES as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nombre de tabla propio y fijo.
		}
		foreach ( self::OPTIONS as $option ) {
			delete_option( $option );
		}
		foreach ( wp_roles()->role_objects as $role ) {
			if ( $role->has_cap( self::CAPABILITY ) ) {
				$role->remove_cap( self::CAPABILITY );
			}
		}
		Jobs::unscheduleAll();
		$file = CompiledConfig::path( EarlyLoader::dataDir(), get_current_blog_id(), is_multisite() );
		if ( is_file( $file ) ) {
			wp_delete_file( $file );
		}
	}

	/**
	 * Borra el directorio de datos si solo quedan los archivos de protección.
	 * Si el administrador dejó el archivo de kill switch, se respeta.
	 */
	private static function removeDataDirIfUnused( string $dataDir ): void {
		if ( ! is_dir( $dataDir ) || is_file( $dataDir . '/' . KillSwitch::FILE ) ) {
			return;
		}
		$entries = scandir( $dataDir );
		if ( false === $entries ) {
			return;
		}
		$rest = array_diff( $entries, [ '.', '..', 'index.php', '.htaccess', 'web.config' ] );
		foreach ( $rest as $entry ) {
			// Configs compiladas de otros sitios de la red siguen en uso.
			if ( str_starts_with( $entry, 'config' ) ) {
				return;
			}
		}
		if ( defined( 'WP_CONTENT_DIR' ) ) {
			Filesystem::removeDir( $dataDir, WP_CONTENT_DIR );
		}
	}
}
