<?php
/**
 * Inventario de assets de una página, en una petición del sitio a sí mismo (loopback) firmada con
 * la cookie itb_assets_inv. Funciona aunque el módulo esté apagado: es lo que se usa para decidir
 * las reglas antes de activarlo.
 *
 * Al final del pie (después de wp_print_footer_scripts) guarda en un transient, con el identificador
 * de la petición (?itb_nc=), lo que la página imprimió: handles, origen, dependencias, si se
 * encolaron directamente o solo como dependencia, y los shortcodes y bloques que se renderizaron.
 * No va en el HTML: así ninguna optimización del plugin de caché (combinar, minificar, retrasar JS)
 * puede alterarlo. La cookie nunca llega a un navegador y la respuesta no se guarda en caché.
 * Mientras se inventaría, las reglas no se aplican (se quiere ver la página completa).
 *
 * @package ImaginaTurbo
 */

declare(strict_types=1);

namespace ImaginaTurbo\Modules\AssetManager;

use ImaginaTurbo\Core\Plugin;
use ImaginaTurbo\Core\Safety\AdminBypassCookie;

/**
 * Recolección.
 *
 * @phpstan-type Asset array{handle: string, src: string, deps: list<string>, footer: bool, enqueued: bool}
 * @phpstan-type Page array{template: string, id: int, post_type: string, js: list<Asset>, css: list<Asset>, shortcodes: list<string>, blocks: list<string>}
 */
final class AssetInventory {

	public const COOKIE = 'itb_assets_inv';

	/** Vida de la cookie: lo que dura una inspección. */
	public const TTL = 300;

	public const TRANSIENT = 'itb_assets_inv_';

	private static bool $active = false;

	private static string $nonce = '';

	/** @var array<string, true> */
	private static array $shortcodes = [];

	/** @var array<string, true> */
	private static array $blocks = [];

	/** Hojas ya impresas al terminar el head; -1 = el head no terminó (0.16.0). */
	private static int $headCss = -1;

	/** @var array<int, array{id: int, title: string, type: string, bytes: int, tags: int, imgs: int, where: string}> Documentos de Elementor impresos (0.17.0). */
	private static array $docs = [];

	public static function active(): bool {
		return self::$active;
	}

	/**
	 * Si la cookie es válida, prepara la recolección.
	 */
	public static function register(): void {
		$key = AdminBypassCookie::key( self::COOKIE );
		if ( null === $key || ! isset( $_COOKIE[ self::COOKIE ] ) ) {
			return;
		}
		if ( null === AdminBypassCookie::validate( wp_unslash( $_COOKIE[ self::COOKIE ] ), $key, time() ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- se valida con HMAC.
			return;
		}
		$nonce = isset( $_GET['itb_nc'] ) ? sanitize_key( wp_unslash( $_GET['itb_nc'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- la autorización es la cookie firmada.
		if ( 1 !== preg_match( '/^[a-z0-9]{8,24}$/', $nonce ) ) {
			return;
		}
		self::$nonce  = $nonce;
		self::$active = true;
		add_action( 'init', [ Plugin::class, 'noPageCache' ], 0 );
		add_filter( 'do_shortcode_tag', [ self::class, 'shortcode' ], 10, 2 );
		add_filter( 'render_block', [ self::class, 'block' ], 10, 2 );
		add_action( 'wp_footer', [ self::class, 'output' ], PHP_INT_MAX );
		add_action( 'wp_head', [ self::class, 'markHead' ], PHP_INT_MAX );
		add_filter( 'elementor/frontend/the_content', [ self::class, 'document' ], 5 );
	}

	/**
	 * Documento de Elementor impreso (bloques HTML, plantillas, la propia página): tamaño, etiquetas,
	 * imágenes y dónde (menú, cabecera, pie o contenido). Para sugerir qué diferir (0.17.0).
	 *
	 * @param mixed $content HTML del documento.
	 * @return mixed
	 */
	public static function document( mixed $content ): mixed {
		if ( ! is_string( $content ) || count( self::$docs ) >= 80 || ! class_exists( '\Elementor\Plugin' ) || ! isset( \Elementor\Plugin::$instance->documents ) ) {
			return $content;
		}
		$document = \Elementor\Plugin::$instance->documents->get_current();
		$id       = is_object( $document ) && method_exists( $document, 'get_main_id' ) ? (int) $document->get_main_id() : 0;
		if ( $id <= 0 ) {
			return $content;
		}
		$stats = self::htmlStats( $content );
		if ( isset( self::$docs[ $id ] ) && self::$docs[ $id ]['bytes'] >= $stats['bytes'] ) {
			return $content;
		}
		self::$docs[ $id ] = [
			'id'    => $id,
			'title' => html_entity_decode( (string) get_the_title( $id ), ENT_QUOTES ),
			'type'  => (string) get_post_type( $id ),
			'where' => self::where( array_column( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 80 ), 'function' ) ), // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace -- solo en la petición de inventario del admin.
		] + $stats;
		return $content;
	}

	/**
	 * Dónde se imprimió, por las funciones de la pila.
	 *
	 * @param array<mixed> $functions Nombres de función de debug_backtrace.
	 */
	public static function where( array $functions ): string {
		foreach ( [
			'wp_nav_menu' => 'menu',
			'get_footer'  => 'footer',
			'get_header'  => 'header',
		] as $function => $where ) {
			if ( in_array( $function, $functions, true ) ) {
				return $where;
			}
		}
		return 'content';
	}

	/**
	 * @return array{bytes: int, tags: int, imgs: int}
	 */
	public static function htmlStats( string $html ): array {
		return [
			'bytes' => strlen( $html ),
			'tags'  => max( 0, substr_count( $html, '<' ) - substr_count( $html, '</' ) - substr_count( $html, '<!' ) ),
			'imgs'  => substr_count( $html, '<img' ),
		];
	}

	public static function markHead(): void {
		self::$headCss = count( wp_styles()->done );
	}

	/**
	 * Hojas externas impresas después del head (handle, URL, versión, media), en orden de impresión.
	 *
	 * @return list<array{h: string, src: string, ver: string, media: string}>
	 */
	public static function lateStyles( \WP_Styles $styles, int $headCount ): array {
		if ( $headCount < 0 ) {
			return [];
		}
		$out = [];
		foreach ( array_slice( $styles->done, $headCount ) as $handle ) {
			$item = $styles->registered[ $handle ] ?? null;
			if ( ! $item instanceof \_WP_Dependency || ! is_string( $item->src ) || '' === $item->src ) {
				continue;
			}
			$out[] = [
				'h'     => (string) $handle,
				'src'   => $item->src,
				'ver'   => is_string( $item->ver ) ? $item->ver : '',
				'media' => is_string( $item->args ) ? $item->args : 'all',
			];
			if ( count( $out ) >= 100 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * @param mixed $output Salida del shortcode.
	 * @return mixed
	 */
	public static function shortcode( mixed $output, mixed $tag ): mixed {
		if ( is_string( $tag ) && count( self::$shortcodes ) < 200 ) {
			self::$shortcodes[ $tag ] = true;
		}
		return $output;
	}

	/**
	 * @param mixed $content Salida del bloque.
	 * @return mixed
	 */
	public static function block( mixed $content, mixed $block ): mixed {
		if ( is_array( $block ) && is_string( $block['blockName'] ?? null ) && count( self::$blocks ) < 200 ) {
			self::$blocks[ $block['blockName'] ] = true;
		}
		return $content;
	}

	/**
	 * Guarda el inventario al final del pie.
	 */
	public static function output(): void {
		$context = AssetManagerModule::context();
		$data    = [
			'template'   => $context['template'],
			'id'         => $context['id'],
			'post_type'  => $context['post_type'],
			'js'         => self::assets( wp_scripts() ),
			'css'        => self::assets( wp_styles() ),
			'shortcodes' => array_keys( self::$shortcodes ),
			'blocks'     => array_keys( self::$blocks ),
			'late_css'   => self::lateStyles( wp_styles(), self::$headCss ),
			'el_docs'    => array_values( self::$docs ),
		];
		set_transient( self::TRANSIENT . self::$nonce, $data, self::TTL );
	}

	/**
	 * Lo que se imprimió de un tipo de dependencia.
	 *
	 * @return list<Asset>
	 */
	public static function assets( \WP_Dependencies $deps ): array {
		$out = [];
		foreach ( $deps->done as $handle ) {
			$item = $deps->registered[ $handle ] ?? null;
			if ( ! $item instanceof \_WP_Dependency ) {
				continue;
			}
			$out[] = [
				'handle'   => (string) $handle,
				'src'      => is_string( $item->src ) ? $item->src : '',
				'deps'     => array_values( array_map( 'strval', $item->deps ) ),
				'footer'   => ( $deps instanceof \WP_Scripts && in_array( $handle, $deps->in_footer, true ) ) || 1 === (int) ( $item->extra['group'] ?? 0 ),
				'enqueued' => in_array( $handle, $deps->queue, true ),
			];
			if ( count( $out ) >= 300 ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Lee (y borra) el inventario de una petición.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function take( string $nonce ): ?array {
		$data = get_transient( self::TRANSIENT . $nonce );
		delete_transient( self::TRANSIENT . $nonce );
		return is_array( $data ) ? $data : null;
	}
}
