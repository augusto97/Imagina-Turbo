<?php
/**
 * Guardia PHP del escudo (docs/02 módulo 6): corta tráfico basura antes de cargar plugins y tema.
 *
 * Corre en la etapa temprana (loader MU): sin funciones de WordPress, sin base de datos y sin
 * autoloader. Solo usa RequestType, que la etapa temprana ya cargó.
 *
 * - Asset inexistente que llegó a PHP (StaticMiss) → 404 vacío, cacheable 10 minutos.
 * - ?author=N sin sesión → 404 (enumeración de usuarios).
 * - XML-RPC → 403, salvo que un plugin activo lo requiera (la config ya lo resolvió).
 * - /wp-json/wp/v2/users sin sesión ni credenciales → 401, salvo que un plugin lo requiera.
 * - Precarga especulativa (Sec-Purpose: prefetch, de Speculation Rules, Speed Brain o cualquier otro
 *   script) de una URL con efectos → 503 sin ejecutar nada: agregar o quitar del carrito, cerrar sesión,
 *   enlaces con nonce, carrito, pago y cuenta. El navegador descarta la precarga y hace la petición
 *   normal si el visitante sí abre el enlace. Las reglas de Imagina Turbo ya excluyen estas URL; esto
 *   cubre las de otros (0.11.0).
 * - Crawler que pide una combinación de filtros de la tienda (dos filtros a la vez, varios valores de
 *   un filtro, precio con otro filtro y, si se activa, orden o vista del listado) → 403 sin ejecutar
 *   nada (0.21.0). Cada filtro por separado sigue abierto: el crawler conoce la base de cada uno, no
 *   los miles de cruces. Con el alcance "all" (0.21.1), cualquier filtro. Las personas no se ven
 *   afectadas.
 *
 * "Sin sesión" se decide por la presencia de la cookie wordpress_logged_in_: la sesión real todavía no
 * se puede validar aquí, así que un visitante con esa cookie conserva el comportamiento del core.
 *
 * @package ImaginaTurbo
 */

declare(strict_types=1);

namespace ImaginaTurbo\Modules\Shield;

use ImaginaTurbo\Core\Request\RequestType;

/**
 * Decisión y respuesta.
 */
final class EarlyGuard {

	public const STATIC_TTL = 600;

	/**
	 * Qué responder, o null si el request sigue.
	 *
	 * @param array<string, mixed> $shield  Ajustes compilados (static, author, xmlrpc, rest_users).
	 * @param array<mixed>         $get     $_GET.
	 * @param array<mixed>         $cookies $_COOKIE.
	 * @param array<mixed>         $server  $_SERVER.
	 * @return array{status: int, headers: list<string>, body: string, reason: string}|null
	 */
	public static function decide( RequestType $type, string $path, string $restPrefix, array $shield, array $get, array $cookies, array $server ): ?array {
		if ( RequestType::StaticMiss === $type && true === ( $shield['static'] ?? false ) ) {
			return [
				'status'  => 404,
				'headers' => [ 'Content-Type: text/plain; charset=utf-8', 'Cache-Control: public, max-age=' . self::STATIC_TTL, 'X-Robots-Tag: noindex' ],
				'body'    => '',
				'reason'  => 'static_miss',
			];
		}

		$loggedIn = self::hasLoginCookie( $cookies );

		// También con ?wc-ajax= (0.21.2): sin WooCommerce, WordPress resuelve ?author=1 igual.
		if ( in_array( $type, [ RequestType::FrontendHtml, RequestType::WcAjax ], true ) && true === ( $shield['author'] ?? false ) && ! $loggedIn && isset( $get['author'] ) && is_scalar( $get['author'] ) && 1 === preg_match( '/^\s*\d+\s*$/', (string) $get['author'] ) ) {
			return [
				'status'  => 404,
				'headers' => [ 'Content-Type: text/plain; charset=utf-8', 'Cache-Control: no-store', 'X-Robots-Tag: noindex' ],
				'body'    => '',
				'reason'  => 'author',
			];
		}

		$views = true === ( $shield['facets_views'] ?? false );
		$all   = 'all' === ( $shield['facets_scope'] ?? 'combos' );
		if ( RequestType::FrontendHtml === $type && true === ( $shield['facets'] ?? false ) && ! $loggedIn && self::isCrawler( $server ) && self::isFacetCombination( $get, $views, $all ) ) {
			return [
				'status'  => 403,
				'headers' => [ 'Content-Type: text/plain; charset=utf-8', 'Cache-Control: no-store', 'X-Robots-Tag: noindex, nofollow' ],
				'body'    => '',
				'reason'  => 'facets',
			];
		}

		if ( RequestType::XmlRpc === $type && true === ( $shield['xmlrpc'] ?? false ) ) {
			return [
				'status'  => 403,
				'headers' => [ 'Content-Type: text/plain; charset=utf-8', 'Cache-Control: no-store' ],
				'body'    => 'XML-RPC disabled.',
				'reason'  => 'xmlrpc',
			];
		}

		if ( true === ( $shield['prefetch'] ?? false ) && self::isPrefetch( $server ) && self::hasSideEffects( $path, $get, is_array( $shield['prefetch_paths'] ?? null ) ? $shield['prefetch_paths'] : [] ) ) {
			return [
				'status'  => 503,
				'headers' => [ 'Content-Type: text/plain; charset=utf-8', 'Cache-Control: no-store', 'X-Robots-Tag: noindex' ],
				'body'    => '',
				'reason'  => 'prefetch',
			];
		}

		// Cualquier tipo (0.21.2): /?wc-ajax=x&rest_route=/wp/v2/users llega como WcAjax y WordPress la
		// sirve igual en parse_request.
		if ( in_array( $type, [ RequestType::Rest, RequestType::WcAjax, RequestType::FrontendHtml ], true ) && true === ( $shield['rest_users'] ?? false ) && ! $loggedIn && ! self::hasCredentials( $server ) && self::isUsersRoute( $path, $restPrefix, $get ) ) {
			return [
				'status'  => 401,
				'headers' => [ 'Content-Type: application/json; charset=utf-8', 'Cache-Control: no-store' ],
				'body'    => '{"code":"rest_forbidden","message":"Sorry, you are not allowed to do that.","data":{"status":401}}',
				'reason'  => 'rest_users',
			];
		}
		return null;
	}

	/**
	 * Envía la respuesta y termina el request (no se cargan plugins ni tema).
	 *
	 * @param array{status: int, headers: list<string>, body: string, reason: string} $response Respuesta.
	 */
	public static function respond( array $response ): never {
		if ( ! headers_sent() ) {
			http_response_code( $response['status'] );
			foreach ( $response['headers'] as $header ) {
				header( $header, true );
			}
			header( 'X-ITB-Shield: ' . $response['reason'], true );
		}
		echo $response['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cuerpo fijo, sin datos del request.
		exit;
	}

	/**
	 * @param array<mixed> $cookies $_COOKIE.
	 */
	private static function hasLoginCookie( array $cookies ): bool {
		foreach ( array_keys( $cookies ) as $name ) {
			if ( is_string( $name ) && str_starts_with( $name, 'wordpress_logged_in_' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Credenciales HTTP (contraseñas de aplicación, JWT). El .htaccess de WordPress copia la cabecera
	 * Authorization a HTTP_AUTHORIZATION aunque venga vacía: solo cuenta si tiene valor.
	 *
	 * @param array<mixed> $server $_SERVER.
	 */
	private static function hasCredentials( array $server ): bool {
		foreach ( [ 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION', 'PHP_AUTH_USER' ] as $key ) {
			if ( isset( $server[ $key ] ) && is_string( $server[ $key ] ) && '' !== trim( $server[ $key ] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * /wp-json/wp/v2/users… o ?rest_route=/wp/v2/users…
	 *
	 * @param array<mixed> $get $_GET.
	 */
	public static function isUsersRoute( string $path, string $restPrefix, array $get ): bool {
		$base = '/' . trim( $restPrefix, '/' ) . '/wp/v2/users';
		// También detrás de un prefijo de idioma (/en/wp-json/wp/v2/users).
		if ( 1 === preg_match( '#^(/[a-z]{2}(?:[-_][a-z]{2})?)?' . preg_quote( $base, '#' ) . '#', strtolower( $path ) ) ) {
			return true;
		}
		$route = $get['rest_route'] ?? null;
		return is_string( $route ) && str_starts_with( strtolower( '/' . ltrim( $route, '/' ) ), '/wp/v2/users' );
	}

	/** Filtros que no empiezan por filter_ (WooCommerce y WoodMart), con el grupo al que pertenecen. */
	public const FACET_PARAMS = [
		'rating_filter' => 'rating',
		'min_price'     => 'price',
		'max_price'     => 'price',
		'stock_status'  => 'stock',
	];

	/** Orden y vista del listado (WooCommerce, WoodMart y otros temas): nunca cambian el contenido. */
	public const VIEW_PARAMS = [ 'orderby', 'per_page', 'per_row', 'shop_view' ];

	/**
	 * Crawlers por user agent: Googlebot/2.1, bingbot/2.0, Storebot-Google, AhrefsBot; …, los que
	 * enlazan su ficha (+http://…), las arañas, la vista previa de Facebook y Meta, y los de Google sin
	 * "bot". Sin "bot" a secas: los móviles CUBOT lo llevan en el nombre.
	 */
	public const CRAWLER_UA = '/bot[\/;\-]|spider|crawl|\+https?:|facebookexternalhit|meta-external|mediapartners|googleother|google-inspectiontool|slurp/i';

	/**
	 * @param array<mixed> $server $_SERVER.
	 */
	public static function isCrawler( array $server ): bool {
		$ua = $server['HTTP_USER_AGENT'] ?? '';
		return is_string( $ua ) && '' !== $ua && 1 === preg_match( self::CRAWLER_UA, $ua );
	}

	/**
	 * Combinación de filtros: dos grupos a la vez (color y talla, precio y color), varios valores de un
	 * mismo filtro (filter_color=rojo,azul o filter_color[]=…) o, con $views, cualquier orden o vista.
	 * Un solo filtro con un valor es la base y sigue abierto, salvo con $all (0.21.1): entonces cualquier
	 * filtro cuenta y el crawler solo ve las URL reales (categorías, etiquetas, productos).
	 * query_type_* solo dice cómo se combinan los valores, así que no cuenta.
	 *
	 * @param array<mixed> $get $_GET.
	 */
	public static function isFacetCombination( array $get, bool $views, bool $all = false ): bool {
		$groups = 0;
		$multi  = false;
		$view   = false;
		foreach ( self::facetGroups( $get ) as $group => $value ) {
			if ( 'view' === $group ) {
				$view = true;
				continue;
			}
			++$groups;
			$multi = $multi || ! is_scalar( $value ) || str_contains( (string) $value, ',' );
		}
		return ( $views && $view ) || $multi || $groups >= ( $all ? 1 : 2 );
	}

	/**
	 * Grupos de filtros del query (filter_*, precio, valoración y stock), más "view" si hay orden o vista.
	 *
	 * @param array<mixed> $get $_GET.
	 * @return array<string, mixed> Grupo => valor (el primero de cada grupo).
	 */
	public static function facetGroups( array $get ): array {
		$groups = [];
		foreach ( $get as $name => $value ) {
			$name = (string) $name;
			if ( str_starts_with( $name, 'filter_' ) ) {
				$group = $name;
			} elseif ( isset( self::FACET_PARAMS[ $name ] ) ) {
				$group = self::FACET_PARAMS[ $name ];
			} elseif ( in_array( $name, self::VIEW_PARAMS, true ) ) {
				$group = 'view';
			} else {
				continue;
			}
			// Varios valores de un grupo (o un valor que no es texto): se conserva el que lo delata.
			if ( ! isset( $groups[ $group ] ) || ! is_scalar( $value ) || str_contains( (string) $value, ',' ) ) {
				$groups[ $group ] = $value;
			}
		}
		return $groups;
	}

	/** Parámetros que cambian algo al abrir la URL (WooCommerce, core y plugins comunes). */
	public const SIDE_EFFECT_PARAMS = [ 'add-to-cart', 'remove_item', 'undo_item', 'removed_item', 'empty-cart', 'order_again', 'cancel_order', 'add_to_wishlist', 'remove_from_wishlist', 'add-to-compare', '_wpnonce', 'wc-ajax' ];

	/**
	 * Precarga especulativa: Sec-Purpose contiene "prefetch" (también "prefetch;prerender").
	 *
	 * @param array<mixed> $server $_SERVER.
	 */
	public static function isPrefetch( array $server ): bool {
		$purpose = $server['HTTP_SEC_PURPOSE'] ?? ( $server['HTTP_PURPOSE'] ?? '' );
		return is_string( $purpose ) && str_contains( strtolower( $purpose ), 'prefetch' );
	}

	/**
	 * La URL cambia algo al abrirse o es del flujo de compra o de la cuenta.
	 *
	 * @param array<mixed> $get   $_GET.
	 * @param array<mixed> $paths Prefijos de rutas que nunca se precargan (carrito, pago, cuenta).
	 */
	public static function hasSideEffects( string $path, array $get, array $paths ): bool {
		foreach ( self::SIDE_EFFECT_PARAMS as $param ) {
			if ( isset( $get[ $param ] ) ) {
				return true;
			}
		}
		if ( 'logout' === ( $get['action'] ?? null ) || str_contains( $path, 'customer-logout' ) || str_contains( $path, 'wp-login.php' ) ) {
			return true;
		}
		$path = rtrim( $path, '/' );
		foreach ( $paths as $prefix ) {
			if ( ! is_string( $prefix ) ) {
				continue;
			}
			$prefix = rtrim( $prefix, '/' );
			if ( '' !== $prefix && ( $path === $prefix || str_starts_with( $path, $prefix . '/' ) ) ) {
				return true;
			}
		}
		return false;
	}
}
