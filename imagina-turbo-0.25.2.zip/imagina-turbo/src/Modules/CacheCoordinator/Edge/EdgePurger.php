<?php
/**
 * Purga en el edge: Cloudflare con el módulo activo y conectado; si no, NullEdgePurger.
 *
 * @package ImaginaTurbo
 */

declare(strict_types=1);

namespace ImaginaTurbo\Modules\CacheCoordinator\Edge;

/**
 * Contrato de purga en el edge.
 */
interface EdgePurger {

	public function available(): bool;

	/** Purga por tag (si no, se resuelven URLs). */
	public function supportsTags(): bool;

	/**
	 * Si no se pudo purgar todo (límite de la API), devuelve lo que falta y cuántos segundos esperar:
	 * la cola lo reprograma sin repetir lo ya purgado.
	 *
	 * @param list<string> $tags Tags con prefijo.
	 * @param list<string> $urls URLs absolutas.
	 * @return array{ok: bool, error: string, tags_left?: list<string>, urls_left?: list<string>, retry_after?: int}
	 */
	public function purge( array $tags, array $urls, bool $all ): array;
}
